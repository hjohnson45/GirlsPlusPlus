package com.example.girls;

import androidx.appcompat.app.AppCompatActivity;

public class HereActivity extends AppCompatActivity {
}
