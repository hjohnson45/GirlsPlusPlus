package com.example.girls;

import android.location.Location;

public class Meeting {
    private int id;
    private String date, title, description, address;
    private Location location;

    public Meeting (int mId, String mDate, String mTitle, String mDescription, String mAddress, Location mLocation){
        date = mDate;
        id = mId;
        title = mTitle;
        description = mDescription;
        address = mAddress;
        location = mLocation;
    }

    public Meeting (String mDate, String mTitle, String mDescription, String mAddress){
        date = mDate;
        title = mTitle;
        description = mDescription;
        address = mAddress;

    }
}
