package com.example.girls;

import android.location.Location;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MeetingFragment extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    private Location mLocation;
    double latitude, longitude;


    private Song mSong;
    private Album mAlbum;
    private Artist mArtist;
    public static MeetingFragment newInstance(int songId) {
        DetailsFragment fragment = new DetailsFragment();
        Bundle args = new Bundle();
        args.putInt("songId", songId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get the band ID from the intent that started DetailsActivity
        int songId = 1;
        if (getArguments() != null) {
            songId = getArguments().getInt("songId");
        }

        mSong = MusicDatabase.getInstance(getContext()).getSong(songId);
        mAlbum = MusicDatabase.getInstance(getContext()).getAlbum(mSong.getAlbum());
        mArtist = MusicDatabase.getInstance(getContext()).getArtist(mAlbum.getArtist());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_details, container, false);

        TextView nameTextView = (TextView) view.findViewById(R.id.songName);
        nameTextView.setText(mSong.getSong());

        TextView descriptionTextView = (TextView) view.findViewById(R.id.bandDescription);
        descriptionTextView.setText("Album: " + mSong.getAlbum() +
                "   Release Year: " + mAlbum.getReleaseYear() +
                "   Track Length: " + mSong.getSongLength() +
                "   Artist: " + mAlbum.getArtist() +
                "   About the Artist: " + mArtist.getDescription());



        return view;
    }


    public MeetingFragment() {
        // Required empty public constructor
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_meeting);

        latitude = mLocation.getLatitude();
        longitude = mLocation.getLongitude();
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng myLocation = new LatLng(latitude, longitude);
        mMap.addMarker(new MarkerOptions().position(myLocation).title("Your Location"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(myLocation));
    }
}
