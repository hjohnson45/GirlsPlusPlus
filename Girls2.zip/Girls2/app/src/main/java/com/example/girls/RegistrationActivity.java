package com.example.girls;


import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class RegistrationActivity extends AppCompatActivity {
    private EditText username,password,fullname,major;
    private Spinner gender_spinner, classification_spinner;
    private Button resetbtn,confirmbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        fullname = (EditText) findViewById(R.id.fullname);
        major = (EditText) findViewById(R.id.major);
        gender_spinner = (Spinner) findViewById(R.id.gender_spinner);
        classification_spinner = (Spinner) findViewById(R.id.classification_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.gender_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        gender_spinner.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter_class = ArrayAdapter.createFromResource(this,
                R.array.classification_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        classification_spinner.setAdapter(adapter_class);

        resetbtn = (Button) findViewById(R.id.Reset);
        confirmbtn = (Button) findViewById(R.id.Confirm);
        resetbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                username.setText("");
                password.setText("");
                fullname.setText("");
                major.setText("");
            }
        });
        confirmbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}
